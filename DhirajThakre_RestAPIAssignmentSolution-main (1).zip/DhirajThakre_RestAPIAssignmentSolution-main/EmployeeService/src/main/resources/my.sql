 insert into roles values('1','ADMIN');
 INSERT INTO USERS VALUES('1','$2a$12$Flp9iE2bTAJLGI1AmPJtquzTFLaoVyTLKqr8OhRURZJignqQxuAHm','user1');
 insert into users_roles values(1,1);